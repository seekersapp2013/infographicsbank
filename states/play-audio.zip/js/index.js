//Defining variable based on unique ID

var audio1 = document.getElementById("audioID");

//Example of an HTML Audio/Video Method

function playAudio() {
  audio1.play();
}